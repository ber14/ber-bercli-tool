import time
from rich.console import Console
from rich.live import Live


console = Console()
colors = ["bright_red", "bright_yellow", "bright_green", "bright_cyan", "bright_blue", "bright_magenta"]

with Live("", refresh_per_second=10) as live:
    for i in range(40):
        time.sleep(0.1)
        current_color = colors[i % len(colors)]
       
        live.update(f"[bold black on {current_color}] ⏳ LOGGING in SAFELY... [/bold black on {current_color}]")


import typer
import pyfiglet
from rich.console import Console

app = typer.Typer()
console = Console()

def show_banner():
   
    ascii_banner = pyfiglet.figlet_format("ber ber cli", font="slant")
    

    console.print(f"[bold cyan]{ascii_banner}[/bold cyan]")
    console.print("[bold magenta][dim]Welcome to my awesome CLI tool![/dim]\n")

@app.command()
def start():

    show_banner()
    BRIGHT_CYAN = "\033[1;96m"
    BRIGHT_YELLOW = "\033[1;93m"
    RESET = "\033[0m"
    console.print("[bold red] /e to exit [/bold red]")
    while True:
        inp = input(F"{BRIGHT_CYAN}you: {BRIGHT_YELLOW}")
        if "create" in inp:
            inp2 = input(F"{BRIGHT_CYAN}FOLDER NAME: {BRIGHT_YELLOW}")
            import os
            os.mkdir(inp2)         
        
        else: console.print("[bold yellow]OK")

        if inp == "/e":
            break
        



    

if __name__ == "__main__":
    app()

